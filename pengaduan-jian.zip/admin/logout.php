<?php
session_start();
include '../koneksi.php';

$username = $_SESSION['username'];
$nama_petugas = $_SESSION['nama_petugas'];


$update_sql = "UPDATE petugas SET is_logged_in=0 WHERE username='$username'";
mysqli_query($koneksi, $update_sql);


session_destroy();


//durasi cookie jadi expired
if (isset($_COOKIE['username'])) {
    setcookie('username', '', time() - 3600, '/'); 
}
if (isset($_COOKIE['nama_petugas'])) {
    setcookie('nama_petugas', '', time() - 3600, '/'); 
}

header('location: ../index2.php');
?>
