<?php
include '../koneksi.php';
include '../sweetalert.php';

$id_pengaduan = isset($_GET['id']) ? $_GET['id'] : '';

if (empty($id_pengaduan)) {
    echo "<script>Swal.fire('Gagal', 'ID Pengaduan tidak ditemukan.', 'error').then(function() { window.location.href='admin.php?url=verifikasi_pengaduan'; });</script>";
    exit;
}

$sql_update = "UPDATE pengaduan SET status='Selesai' WHERE id_pengaduan='$id_pengaduan'";
$data_update = mysqli_query($koneksi, $sql_update);

if ($data_update) {
    $tanggapan = 'Terimakasih sudah melaporkan, laporan anda sudah ditangani oleh pihak kami.';
    $tgl_tanggapan = date('Y-m-d');

    $check_tanggapan = mysqli_query($koneksi, "SELECT * FROM tanggapan WHERE id_pengaduan='$id_pengaduan'");
    
    if (mysqli_num_rows($check_tanggapan) == 0) {
        $query_insert = "INSERT INTO tanggapan (id_pengaduan, tanggapan, tgl_tanggapan) VALUES ('$id_pengaduan', '$tanggapan', '$tgl_tanggapan')";
        if (mysqli_query($koneksi, $query_insert)) {
            echo "<script>popupBerhasil(); setTimeout(function() { window.location.href='admin.php?url=verifikasi_pengaduan'; }, 2000);</script>";
        } else {
            echo "<script>Swal.fire('Gagal', 'Gagal menambahkan tanggapan.', 'error').then(function() { window.location.href='admin.php?url=verifikasi_pengaduan'; });</script>";
        }
    } else {
        echo "<script>popupBerhasil(); setTimeout(function() { window.location.href='admin.php?url=verifikasi_pengaduan'; }, 2000);</script>";
    }
} else {
    echo "<script>Swal.fire('Gagal', 'Gagal memperbarui status pengaduan.', 'error').then(function() { window.location.href='admin.php?url=verifikasi_pengaduan'; });</script>";
}
?>

<script>
function popupBerhasil() {
    Swal.fire({
        title: "Berhasil!!",
        text: "Berhasil Menyelesaikan Laporan Yang Diterima",
        icon: "success"
    });
}
</script>
