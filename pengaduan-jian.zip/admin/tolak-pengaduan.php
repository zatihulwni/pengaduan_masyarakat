<?php
$id = $_GET['id'];
if (empty($id)) {
    header("Location:masyarakat.php");
    exit;
}

include '../koneksi.php';
$id_pengaduan = isset($_GET['id']) ? $_GET['id'] : $_POST['id_pengaduan'];
$sql = "UPDATE pengaduan SET status='Ditolak' WHERE id_pengaduan='$id_pengaduan'";
$data = mysqli_query($koneksi, $sql);

if ($data) {
    
    $tanggapan ='Maaf, laporan kamu ditolak. Mohon berikan foto bukti dengan jelas!';
    $tgl_tanggapan = date('Y-m-d'); 

    $query = "INSERT INTO tanggapan (id_pengaduan, tanggapan, tgl_tanggapan) VALUES ('$id_pengaduan', '$tanggapan', '$tgl_tanggapan')";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Laporan Telah Ditolak!'); window.location.href='admin.php?url=verifikasi_pengaduan';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan tanggapan.'); window.location.href='admin.php?url=verifikasi_pengaduan';</script>";
    }
} else {
    echo "<script>alert('Gagal memperbarui status laporan.'); window.location.href='admin.php?url=verifikasi_pengaduan';</script>";
}
?>

<div class="card shadow">
    <div class="card-header">
        <a href="?url=lihat-pengaduan" class="btn btn-primary btn-icon-split">
            <span class="icon text-white-50">
                <i class="fa fa-arrow-left"></i>
            </span>
            <span class="text">Kembali</span>
        </a>
    </div>
    <div class="card-body">
    <form method="post" action="tolak-pengaduan.php" enctype="multipart/form-data">
    <input type="hidden" name="id_pengaduan" value="<?= $data['id_pengaduan']; ?>">
    <div class="form-group">
        <label style="font-size: 14px;">Tgl Pengaduan</label>
        <input type="text" name="tgl_pengaduan" class="form-control" readonly value="<?= $data['Tgl_pengaduan']; ?>">
    </div>
    <div class="form-group">
        <label style="font-size: 14px;">Isi Laporan</label>
        <textarea name="isi_laporan" class="form-control" required><?= $data['isi_laporan']; ?></textarea>
    </div>
    <div class="form-group">
        <label style="font-size: 14px;">Foto</label>
        <img class="img-thumbnail" src="../foto/<?= $data['foto'] ?>" width="300">
    </div>
    <div class="form-group">
        <label style="font-size: 14px;">Tanggapan</label>
        <input type="text" name="tanggapan" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-success">Submit</button>
</form>

    </div>
</div>
