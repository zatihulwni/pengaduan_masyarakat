<?php
session_start();
include '../koneksi.php';

$username = $_SESSION['username'];
$update_sql = "UPDATE petugas SET is_logged_in=0 WHERE username='$username'";
mysqli_query($koneksi, $update_sql);

session_destroy();
header('location: ../index.php');
?>
