<div class="card shadow mb-4">
<div class="card-header py-3">
<h6 class="m-0 font-weight-bold text-primary">Verifikasi Laporan</h6>
</div>
    <div class="card-body" style="font-size: 14px">
    <div class="table-responsive">
<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>ID Pengaduan</th>
            <th>Tgl Pengaduan</th>
            <th>NIK</th>
            <th>Isi Laporan</th>
            <th>Foto</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
<?php
    include '../koneksi.php';
    $sql = "SELECT * FROM pengaduan where status = 'Menunggu Verifikasi' ORDER BY id_pengaduan DESC";
$query = mysqli_query($koneksi, $sql); $no = 1;
    while ($data = mysqli_fetch_array($query)) { ?>
        <tr>
            <td><?= $data['id_pengaduan']; ?></td>
            <td><?= $data['Tgl_pengaduan']; ?></td>
            <td><?= $data['nik']; ?></td>
            <td><?= $data['isi_laporan']; ?></td>
            <td>
                                <?php if (!empty($data['foto'])) { ?>
                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modalFoto<?= $data['id_pengaduan']; ?>">
                                        Lihat Foto
                                    </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="modalFoto<?= $data['id_pengaduan']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Foto Pengaduan</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body text-center">
                                                        <img src="../foto/<?= $data['foto']; ?>" alt="Foto Pengaduan" class="img-fluid">
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                <?php } else { ?>
                                    <span class="text-danger">Tidak ada foto</span>
                                <?php } ?>
                            </td>
            <td><?= $data['status']; ?></td>
            <td>
                <a href="?url=proses&id=<?= $data['id_pengaduan'] ?>" class="btn btn-primary btn-icon-split btn-sm">
                <span class="icon text-white-50"><i class="fa fa-info"></i></span>
                <span class="text">Verifikasi</span>
                </a>
                <br><br>

                <a href="?url=tolak&id=<?= $data['id_pengaduan'] ?>" class="btn btn-danger btn-icon-split btn-sm">
                <span class="icon text-white-50"><i class="fa fa-info"></i></span>
                <span class="text">Tolak</span>
                </a><br><br>

                <a href="?url=selesai&id=<?= $data['id_pengaduan'] ?>" class="btn btn-success btn-icon-split btn-sm">
                <span class="icon text-white-50"><i class="fa fa-check"></i></span>
                <span class="text">Selesai</span>
                </a>
            </td>

        </tr>
    <?php } ?>
    </tbody>
</table>
</div>
</div>
</div>