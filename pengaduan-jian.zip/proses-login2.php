<?php
session_start();
//mencegah dua login dalam satu browser
if (isset($_SESSION['username']))/*kalau ada sesi yang kesimpan berupa username, maka munculin alert*/  {
    echo "<script>alert('Anda sedang login sebagai ".$_SESSION['username'].", silahkan logout dari ".$_SESSION['username']." terlebih dahulu untuk memulai sesi ini.'); window.location.assign('index2.php'); </script>";
    exit;
}

include 'koneksi.php';
$username = $_POST['username'];
$password = $_POST['password'];
$remember = isset($_POST['remember']);

$sql = "SELECT * FROM petugas WHERE username='$username'";
$query = mysqli_query($koneksi, $sql);

if(mysqli_num_rows($query) > 0) {
    $data = mysqli_fetch_array($query);

    $sql_cek_login = "SELECT * FROM petugas WHERE username='$username' AND is_logged_in=1";
    $query_cek_login = mysqli_query($koneksi, $sql_cek_login);

    if(mysqli_num_rows($query_cek_login) > 0) {
        echo "<script>alert('Anda sedang login sebagai ".$data['username']."'); window.location.assign('index2.php'); </script>";
        exit;
    }

    if(password_verify($password, $data['password']))/*buat ngebaca password yang dihash*/ {
        $_SESSION['nama_petugas'] = $data['nama_petugas'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['level'] = $data['level'];

        $update_sql = "UPDATE petugas SET is_logged_in=1 WHERE username='$username'";//kalau berhasil login, ubah value dari 0 jadi 1
        mysqli_query($koneksi, $update_sql);

        /*set cookie saat remember me dicentang (START)*/
        if ($remember) {    
            setcookie('username', $data['username'], time() + (30 * 24 * 60 * 60), "/");
            setcookie('nama_petugas', $data['nama_petugas'], time() + (30 * 24 * 60 * 60), "/");
        }
        /*set cookie saat remember me dicentang (END)*/


        /*ngedirect halaman sesuai sama level (START)*/
        if ($data['level'] == "admin") {
            header("location:admin/admin.php");
        } elseif ($data['level'] == "petugas") {
            header("location:petugas/petugas.php");
        } /*ngedirect halaman sesuai sama level (END)*/

    } else {
        echo "<script>alert('Maaf Anda Gagal Login. Password tidak valid.'); window.location.assign('index2.php'); </script>";
    }
} else {
    echo "<script>alert('Maaf Anda Gagal Login. Username tidak ditemukan.'); window.location.assign('index2.php'); </script>";
}
?>